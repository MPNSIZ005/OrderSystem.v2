﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OrderSystem.BusinessLayer;

namespace OrderSystem.PresentationLayer
{
    public partial class LoginForm : Form
    {
        private EmployeeController employeeController;
        public bool loginFormClosed = false;

        #region Constructor
        public LoginForm(EmployeeController employeeController)
        {
            InitializeComponent();
            //IsMdiContainer = true;
            this.employeeController = employeeController;
            errorLabel.Visible = false;
        }
        #endregion

        #region Form Actions

        private void LoginForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            loginFormClosed = true;
        }

        #endregion

        private void LoginButton_Click(object sender, EventArgs e)
        {
            Collection<Employee> allEmployees = employeeController.AllEmployees;
            Employee emp = null;
            bool employeeFound = false;

            foreach (Employee eachEmployee in allEmployees)  // searching through all employees to check for the entered user
            {
                if (eachEmployee.EmployeeID.Equals(UserNameTextBox.Text.ToUpper()))
                {
                    employeeFound = true;
                    emp = eachEmployee;
                    break;
                }
            }


            if (employeeFound == true)   // user does exist
            {
                if (emp.Password.Equals(PasswordTextBox.Text))
                {
                    MessageBox.Show("Successfully logged in");
                    if (emp.RoleValue == Employee.Role.pickingClerk)   // if the user is a picking clerk
                    {
                        ((PoppelMDIParent)this.MdiParent).pickClerkLogin();
                        MessageBox.Show("Successfully logged is as Picking Clerk");
                    }
                    else
                    {
                        ((PoppelMDIParent)this.MdiParent).TellerSellerLogin();  // if user is a packing clerk
                        MessageBox.Show("Successfully logged is as Teller Seller");
                    }
                    
                    this.Close();
                }

                else
                {
                    PasswordTextBox.Text = "";
                    errorLabel.Text = "The password that you've entered is incorrect.";
                    errorLabel.Visible = true;
                }
            }

            else //if user doesn't exist
            {
                PasswordTextBox.Text = "";
                errorLabel.Text = "The username or password you entered is incorrect.Please try again.";
                errorLabel.Visible = true;
            }

        }
    }
}
