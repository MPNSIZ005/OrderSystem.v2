﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OrderSystem.BusinessLayer;

namespace OrderSystem.PresentationLayer
{
    public partial class PickingListForm : Form
    {
        #region Data Members
        public bool listFormClosed = false;
        private OrderItemsController orderItemsController;
        private CustomerController customerController;
        private ProductController productController;
        private OrderController orderController;
        private EmployeeController employeeController;
        private Order order;
        private Employee employee;
        private Collection<OrderItems> orderItems;
        private Collection<Product> products;

        #endregion
        #region Constructor
        public PickingListForm(ProductController aProductController, CustomerController aCustomerController, EmployeeController anEmployeeController)
        {
            InitializeComponent();
            productController = aProductController;
            customerController = aCustomerController;
            employeeController = anEmployeeController;
            orderItemsController = new OrderItemsController();
            orderController = new OrderController();
            FillCombo();
            ItemsListView();
            HideAll(false);
        }
        #endregion
        private void PickingListForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            listFormClosed = true;
        }

        private void doneButton_Click(object sender, EventArgs e)
        {
            printPreviewButton.Visible = true;
            if (order != null)
            {
                //Ask user if they want to confirm order
                if (MessageBox.Show("Are you sure you want to confirm order as picked?", "Confirming Order", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    printPreviewButton.Visible = true;
                    // Here we change the order status to be picked and clear the picking list
                    order.OrderValue = Order.OrderStatus.picked;
                    orderController.DataMaintenance(order, DatabaseLayer.DB.DBOperation.Edit);

                    //if (orderController.FinalizeChanges(order) == true)
                    //{
                    //    ordersComboBox.Items.Remove(ordersComboBox.SelectedItem); //remove item from combo box when picked
                    //}

                    orderController.FinalizeChanges(order);
                    //orderItemsListView.Clear();
                    ItemsListView();
                    //orderItemsListView.Refresh();
                    ordersComboBox.SelectedIndex = -1;
                    ordersComboBox.Text = "";
                    order = null;
                    //HideAll(false);
                }
                else
                {
                    this.Activate();
                }
            }

            else
            {
                MessageBox.Show("Cannot finilaze a order without generating a order list");
            }
        }

        private void backButton_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to close form?", "Closing form", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void OKbutton_Click(object sender, EventArgs e)
        {
            order = default(Order);
            employee = default(Employee);
            order = (Order)ordersComboBox.SelectedItem;
            backButton.Visible = true;
            doneButton.Visible = true;
            //Cannot create a list id no order is selected
            if (order == null)
            {
                MessageBox.Show("First select an order to generate a picking list");
            }

            else
            {
                orderDateLabel.Text = Convert.ToString(order.OrderDate);
                Customer customer = customerController.Find(order.CustomerID);
                customerIDLabel.Text = customer.CustomerID;
                customerNameLabel.Text = customer.Name + " " + customer.Surname;
                customerAddressLabel.Text = customer.CustomerAddress;
                orderIDLabel.Text = order.OrderID;
                clerkIDLabel.Text = "EMP001";
                HideAll(true);
                ItemsListView();
            }
        }

        private void printButton_Click(object sender, EventArgs e)
        {
            PoppelprintDialog.Document = PoppelprintDocument;
            if (PoppelprintDialog.ShowDialog() == DialogResult.OK)
            {
                PoppelprintDocument.Print();
            }
        }

        private void printPreviewButton_Click(object sender, EventArgs e)
        {
            PoppelprintPreviewDialog.Document = PoppelprintDocument;
            PoppelprintPreviewDialog.ShowDialog();
            printButton.Visible = true;
        }

        #region Methods
        public void HideAll(bool value)
        {
            orderDateLabel.Visible = value;
            customerIDLabel.Visible = value;
            customerNameLabel.Visible = value;
            customerAddressLabel.Visible = value;
            orderIDLabel.Visible = value;
            clerkIDLabel.Visible = value;
        }
        public void FillCombo()
        {
            Collection<Order> orders = new Collection<Order>();
            orderController = new OrderController();
            orders = orderController.FindByStatus(Order.OrderStatus.unpicked);
            //Link the objects in the collection of unpicked orders to every item of the combo box
            foreach (Order eachOrder in orders)
            {
                ordersComboBox.Items.Add(eachOrder);
            }

            // Allow to search on combo box
            ordersComboBox.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            ordersComboBox.AutoCompleteSource = AutoCompleteSource.ListItems;
            //Set the current display of the combobox to nothing
            ordersComboBox.SelectedIndex = -1;
            ordersComboBox.Text = "";
        }

        public void ItemsListView()
        {
            ListViewItem itemDetails;
            // order = new Order();
            order = (Order)ordersComboBox.SelectedItem;   // reading from the combo box
            orderItemsListView.Clear();

            if (order == null)  // If nothing has been selected yet on the combo box
            {
                //Set Up Columns of List View
                orderItemsListView.View = View.Details;
                orderItemsListView.Columns.Insert(0, "Product ID", 133, HorizontalAlignment.Left);
                orderItemsListView.Columns.Insert(1, "Product Name", 140, HorizontalAlignment.Left);
                orderItemsListView.Columns.Insert(2, "Quantity", 133, HorizontalAlignment.Left);
            }

            else
            {
                orderItemsListView.View = View.Details;
                orderItemsListView.Columns.Insert(0, "Product ID", 133, HorizontalAlignment.Left);
                orderItemsListView.Columns.Insert(1, "Product Name", 140, HorizontalAlignment.Left);
                orderItemsListView.Columns.Insert(2, "Quantity", 133, HorizontalAlignment.Left);

                orderItems = null;  //employees collection will be filled by role
                orderItems = orderItemsController.FindByOrderID(order.OrderID);

                //Add item details to each ListView item 
                foreach (OrderItems item in orderItems)
                {
                    Product product = productController.Find(item.ProductID);  // get the selected product details
                    itemDetails = new ListViewItem();
                    itemDetails.Text = item.ProductID.ToString();
                    itemDetails.SubItems.Add(product.ProductName);
                    itemDetails.SubItems.Add(item.Quantity.ToString());
                    orderItemsListView.Items.Add(itemDetails);
                }
            }
            orderItemsListView.Refresh();
            orderItemsListView.GridLines = true;
        }

        #endregion

        private void PickingListForm_Load(object sender, EventArgs e)
        {
            printPreviewButton.Visible = false;
            printButton.Visible = false;
            doneButton.Visible = false;
            backButton.Visible = false;
        }


        #region Print Preview (BASICALLY PRINT CUSTOMER AND ORDER DETAILS)
        private void PoppelprintDocument_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString("******************************************" +
                                  "\n" +
                                 "            CUSTOMER DETAILS" +
                                  "\n" +
                                  "******************************************" +
                                  "\n" + "\n" +
                                  "Order Number :  " + orderIDLabel.Text +
                                  "\n" + "\n" +
                                  "Order Date   :  " + orderDateLabel.Text +
                                  "\n" + "\n" +
                                  "Clerk ID     :  " + clerkIDLabel.Text +
                                  "\n" + "\n" +
                                  "CustomerID   :  " + customerIDLabel.Text +
                                  "\n" + "\n" +
                                  "Customer Name:  " + customerNameLabel.Text +
                                  "\n" + "\n" +
                                  "Delivary Address :  " + customerAddressLabel.Text +
                                  "\n" + "\n" +
                                "******************************************" +
                                  "\n" +
                                 "           PRODUCT DETAILS" +
                                  "\n" +
                                "******************************************"
                                 , new Font("Courier New", 12, FontStyle.Regular), Brushes.Black, new Point(25, 150));

            int x = 60;
            int y = 500;
            int offset = 40;

            foreach (ListViewItem Itm in orderItemsListView.Items)
            {
                e.Graphics.DrawString("       POPPEL PICKING LIST", new Font("Courier New", 12, FontStyle.Bold), Brushes.Black, 25, 120);
                e.Graphics.DrawString("ProductID" + "             Product Name" + "         Quantity", new Font("Courier New", 12, FontStyle.Regular), Brushes.Black, 25, 500);
                e.Graphics.DrawString(Itm.Text, new Font("Courier New", 12, FontStyle.Regular), Brushes.Black, 25, y + offset);
                e.Graphics.DrawString(Itm.SubItems[1].Text, new Font("Courier New", 12, FontStyle.Regular), Brushes.Black, 250, y + offset);
                e.Graphics.DrawString(Itm.SubItems[2].Text, new Font("Courier New", 12, FontStyle.Regular), Brushes.Black, 500, y + offset);
                offset = offset + (int)FontHeight + 10;

            }
            offset = offset + 20;

        }
        #endregion        

    }

}
