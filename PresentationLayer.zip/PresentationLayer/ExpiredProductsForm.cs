﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OrderSystem.BusinessLayer;

namespace OrderSystem.PresentationLayer
{
    public partial class ExpiredProductsForm : Form
    {
        #region Attributes
        public bool productsFormClosed = false;
        private ProductController productController;
        private Collection<Product> expiredProducts;
        #endregion
        public ExpiredProductsForm(ProductController productController)
        {
            InitializeComponent();
            this.productController = productController;
            ShowItems();
        }

        private void CloseButton_Click(object sender, EventArgs e)
        {
            productsFormClosed = true;
            this.Close();
        }
        private void ExpiredProductsForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            productsFormClosed = true;
        }
        public void ShowItems()
        {
            ListViewItem itemDetails;
            itemsListView.Clear();
            expiredProducts = null;  //employees collection will be filled by role
            expiredProducts = productController.FindByStatus(Product.productStatus.expired);

            //Set Up Columns of List View
            itemsListView.View = View.Details;
            itemsListView.Columns.Insert(0, "Product ID", 85, HorizontalAlignment.Left);
            itemsListView.Columns.Insert(1, "Product Name", 108, HorizontalAlignment.Left);
            itemsListView.Columns.Insert(2, "Expiry Date", 100, HorizontalAlignment.Left);
            itemsListView.Columns.Insert(3, "Quantity", 85, HorizontalAlignment.Left);

            //Add item details to each ListView item 
            foreach (Product product in expiredProducts)
            {
                itemDetails = new ListViewItem();
                itemDetails.Text = product.ProductID.ToString();
                itemDetails.SubItems.Add(product.ProductName);
                itemDetails.SubItems.Add(product.ExpiryDate.ToString().Substring(0, 10));
                itemDetails.SubItems.Add(product.QuantityInStock.ToString());
                itemsListView.Items.Add(itemDetails);
            }

            itemsListView.Refresh();
            itemsListView.GridLines = true;
        }
    }
}
