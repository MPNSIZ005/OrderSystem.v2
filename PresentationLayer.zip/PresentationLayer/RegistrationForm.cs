﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OrderSystem.BusinessLayer;

namespace OrderSystem.PresentationLayer
{
    public partial class RegistrationForm : Form
    {
        public bool registrationFormClosed = false;
        public bool registrationFormFormClosed = false;
        private Customer customer;
        private CustomerController customerController;
        public RegistrationForm(CustomerController customerController)
        {
            InitializeComponent();
            this.customerController = customerController;
        }

        #region Form Actions
        private void RegistrationForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            registrationFormClosed = true;
        }
        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void SubmitButton_Click(object sender, EventArgs e)
        {
            if (PopulateObject() == true)
            {
                MessageBox.Show("Customer was successfully registered!");
                customerController.DataMaintenance(customer, DatabaseLayer.DB.DBOperation.Add);
                customerController.FinalizeChanges(customer);
                ClearAll();
            }
            else
            {
                MessageBox.Show("Customer was NOT successfully registered");
            }
        }
        private void CancelButton_Click(object sender, EventArgs e)
        {
            ClearAll();
        }
        #endregion

        #region Method
        private void ClearAll()
        {
            NameTextBox.Text = "";
            SurnameTextBox.Text = "";
            phoneTextBox.Text = "";
            IDtextBox.Text = "";
            addressTextBox.Text = "";
        }

        public string CustomerIDGenerator(string name, string surname, string idNumber)
        {
            string customerID = name.ToUpper().Substring(0,1);
            if(surname.Length < 3)
            {
                customerID += surname.ToUpper();
                while (customerID.Length < 3)
                {
                    customerID += "X";
                }
                customerID += name.Substring(0, 3).ToUpper();
            }
            else
            {
                customerID += surname.Substring(0, 3).ToUpper();
            }

            customerID += idNumber.Substring(0, 6);
            return customerID;
        }

        private Boolean PopulateObject()
        {
            //declare phoneNum variable
            int phoneNum;

            //determine if phoneNum is int or string
            bool validPhoneNum = int.TryParse(phoneTextBox.Text, out phoneNum);

            long num;
            if (SurnameTextBox.Text.Equals("") || NameTextBox.Text.Equals("") || phoneTextBox.Text.Equals("") || IDtextBox.Text.Equals("") || addressTextBox.Text.Equals(""))
            {
                MessageBox.Show("One or more of the fields are missing");
                return false;
            }

            else
            {
                if (!long.TryParse(IDtextBox.Text, out num) && !long.TryParse(phoneTextBox.Text, out num))
                {
                    MessageBox.Show("Phone number and ID number must be numeric");
                    return false;
                }

                else if (!long.TryParse(IDtextBox.Text, out num))
                {
                    MessageBox.Show("ID number must be numeric");
                    return false;
                }

                else if (string.IsNullOrEmpty(phoneTextBox.Text) || phoneTextBox.Text.Equals("Enter your Phone number") || validPhoneNum == false || !(phoneTextBox.Text.Length == 10) || !(phoneTextBox.Text.StartsWith("0"))) //start phone number check
                {
                    MessageBox.Show("Phone number MUST be numeric with 0 at the beginning");
                    return false;
                }

                else
                {
                    customer = new Customer();
                    customer.CustomerID = CustomerIDGenerator(NameTextBox.Text, SurnameTextBox.Text, IDtextBox.Text);                                     ///autoGerate
                    customer.Name = NameTextBox.Text;
                    customer.Surname = SurnameTextBox.Text;
                    customer.Phone = phoneTextBox.Text;
                    customer.IDNumber1 = long.Parse(IDtextBox.Text);
                    customer.CurrentCredit = int.Parse("2000");
                    customer.CreditStatus = "1";
                    customer.CustomerAddress = addressTextBox.Text;

                    return true;


                }
            }
        }


        #endregion

    }
}
