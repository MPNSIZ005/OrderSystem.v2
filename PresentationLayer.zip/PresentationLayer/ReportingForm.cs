﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;
using System.Xml;

using OrderSystem.BusinessLayer;
using OrderSystem.DatabaseLayer;
using System.Windows.Forms.DataVisualization.Charting;

namespace OrderSystem.PresentationLayer
{
    public partial class ReportingForm : Form
    {
        private OrderItemsDB orderItemsDB;
        //Declare a reference to a productDB object
        private ProductDB productDB;

        public bool reportingFormClosed = false;
        public ReportingForm()
        {
            InitializeComponent();
            //productDB = new ProductDB();
            orderItemsDB = new OrderItemsDB();
            productDB = new ProductDB();
        }

        private void purchaseReportButton_Click(object sender, EventArgs e)
        {
            DataTable saleReportTable;
            Chart saleReportChart = new Chart();
            //DataSeries pop = new DataSeries();
            //pop.RenderAs = RenderAs.Pie;
            //pop.LegendText = "Sale Report";
            saleReportTable = orderItemsDB.ReadDataOrderItemSpilt();

            foreach (DataRow popRow in saleReportTable.Rows)
            {
                DataPoint aPoint = new DataPoint();
                //aPoint.AxisXLabel = (popRow.ItemArray[0]).ToString();
                //aPoint.YValue = Convert.ToDouble(popRow.ItemArray[1]);
                // Add dataPoint to DataPoints collection
                //pop.DataPoints.Add(aPoint);
            }
            //saleReportChart.Series.Add(pop);
            //saleReportChart.SmartLabelEnabled = true;
            //poppelElementHost.Child = saleReportChart;
        }

        private void quantityInStockButton_Click(object sender, EventArgs e)
        {
            DataTable quantyReportTable;
            Chart quantyReportChart = new Chart();
            //DataSeries quant = new DataSeries();
            //quant.RenderAs = RenderAs.Doughnut;
            //quant.LegendText = "Quantity In Stock";
            quantyReportTable = productDB.ReadDataQuantityInstock();

            foreach (DataRow quantRow in quantyReportTable.Rows)
            {
                DataPoint aPoint = new DataPoint();
                //aPoint.AxisXLabel = (quantRow.ItemArray[0].ToString());
                //aPoint.YValue = Convert.ToDouble(quantRow.ItemArray[1]);

                // Add dataPoint to DataPoints collection
                //quant.DataPoints.Add(aPoint);
            }
            //quantyReportChart.Series.Add(quant);
            //quantyReportChart.SmartLabelEnabled = true;
            //poppelElementHost.Child = quantyReportChart;

            misterSweetApricot.Visible = true;
            AppleDrinkButton.Visible = true;
            orbitChewingButton.Visible = true;
            RobertsonRedWine.Visible = true;
            liquidMangoButton.Visible = true;
        }

        private void ReportingForm_Load(object sender, EventArgs e)
        {
            misterSweetApricot.Visible = false;
            AppleDrinkButton.Visible = false;
            orbitChewingButton.Visible = false;
            RobertsonRedWine.Visible = false;
            liquidMangoButton.Visible = false;
        }
    }
}
