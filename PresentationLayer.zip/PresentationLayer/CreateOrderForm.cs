﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OrderSystem.BusinessLayer;

namespace OrderSystem.PresentationLayer
{
    public partial class CreateOrderForm : Form
    {
        #region Attributes
        public bool createOrderFormClosed = false;
        private CustomerController customerController;
        private Customer aCustomer;
        private Collection<Customer> customers;
        private OrderForm orderForm;
        #endregion
        public CreateOrderForm(CustomerController aCustomerController)
        {
            InitializeComponent();
            customerController = aCustomerController;
            FillCombo();
        }
        private void CreateOrderForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            createOrderFormClosed = true;
        }

        private void Submitbutton_Click(object sender, EventArgs e)
        {
            aCustomer = null;
            aCustomer = (Customer)customersComboBox.SelectedItem;
            if (aCustomer == null)
            {
                MessageBox.Show("First select a customer to create order for before continuing");
            }
            else
            {

                if (CreateNewOrderForm() == true)  // IF credit status is good
                {
                    orderForm.Show();
                    this.Close();
                    createOrderFormClosed = true;
                }

                else // else
                {
                    MessageBox.Show("Cannot create an order for customer with bad credit status");
                }

            }
        }

        private void Clearbutton_Click(object sender, EventArgs e)
        {
            customersComboBox.SelectedIndex = -1;
            customersComboBox.Text = "";
        }
        //--------------------------------------------------
        #region Methods
        public void FillCombo()
        {
            customers = new Collection<Customer>();
            customers = customerController.AllCustomers;
            foreach (Customer eachOrder in customers)
            {
                customersComboBox.Items.Add(eachOrder);
            }
            customersComboBox.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            customersComboBox.AutoCompleteSource = AutoCompleteSource.ListItems;
            customersComboBox.SelectedIndex = -1;
            customersComboBox.Text = "";
        }

        private bool CreateNewOrderForm()
        {
            string creditStatus = aCustomer.CreditStatus;
            if (aCustomer.CreditStatus.Equals("0"))
            {
                return false;
            }

            else
            {
                orderForm = new OrderForm(customerController, aCustomer);
                orderForm.StartPosition = FormStartPosition.CenterParent;
                return true;
            }
        }

        #endregion

    }
}
