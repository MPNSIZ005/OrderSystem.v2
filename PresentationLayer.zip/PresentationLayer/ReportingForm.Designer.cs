﻿
namespace OrderSystem.PresentationLayer
{
    partial class ReportingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.purchaseReportButton = new System.Windows.Forms.Button();
            this.misterSweetApricot = new System.Windows.Forms.Button();
            this.quantityInStockButton = new System.Windows.Forms.Button();
            this.orbitChewingButton = new System.Windows.Forms.Button();
            this.AppleDrinkButton = new System.Windows.Forms.Button();
            this.liquidMangoButton = new System.Windows.Forms.Button();
            this.RobertsonRedWine = new System.Windows.Forms.Button();
            this.elementHost1 = new System.Windows.Forms.Integration.ElementHost();
            this.SuspendLayout();
            // 
            // purchaseReportButton
            // 
            this.purchaseReportButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.purchaseReportButton.Location = new System.Drawing.Point(466, 35);
            this.purchaseReportButton.Name = "purchaseReportButton";
            this.purchaseReportButton.Size = new System.Drawing.Size(126, 65);
            this.purchaseReportButton.TabIndex = 0;
            this.purchaseReportButton.Text = "Purchase Report";
            this.purchaseReportButton.UseVisualStyleBackColor = true;
            this.purchaseReportButton.Click += new System.EventHandler(this.purchaseReportButton_Click);
            // 
            // misterSweetApricot
            // 
            this.misterSweetApricot.BackColor = System.Drawing.SystemColors.HotTrack;
            this.misterSweetApricot.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.misterSweetApricot.Location = new System.Drawing.Point(466, 138);
            this.misterSweetApricot.Name = "misterSweetApricot";
            this.misterSweetApricot.Size = new System.Drawing.Size(126, 57);
            this.misterSweetApricot.TabIndex = 1;
            this.misterSweetApricot.Text = "Mister Sweet Apricot";
            this.misterSweetApricot.UseVisualStyleBackColor = false;
            // 
            // quantityInStockButton
            // 
            this.quantityInStockButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quantityInStockButton.Location = new System.Drawing.Point(633, 35);
            this.quantityInStockButton.Name = "quantityInStockButton";
            this.quantityInStockButton.Size = new System.Drawing.Size(116, 65);
            this.quantityInStockButton.TabIndex = 2;
            this.quantityInStockButton.Text = "Quantity In Stock";
            this.quantityInStockButton.UseVisualStyleBackColor = true;
            this.quantityInStockButton.Click += new System.EventHandler(this.quantityInStockButton_Click);
            // 
            // orbitChewingButton
            // 
            this.orbitChewingButton.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.orbitChewingButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.orbitChewingButton.Location = new System.Drawing.Point(633, 138);
            this.orbitChewingButton.Name = "orbitChewingButton";
            this.orbitChewingButton.Size = new System.Drawing.Size(116, 57);
            this.orbitChewingButton.TabIndex = 3;
            this.orbitChewingButton.Text = "Orbit Chewing Gums";
            this.orbitChewingButton.UseVisualStyleBackColor = false;
            // 
            // AppleDrinkButton
            // 
            this.AppleDrinkButton.BackColor = System.Drawing.Color.Maroon;
            this.AppleDrinkButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AppleDrinkButton.Location = new System.Drawing.Point(466, 233);
            this.AppleDrinkButton.Name = "AppleDrinkButton";
            this.AppleDrinkButton.Size = new System.Drawing.Size(126, 66);
            this.AppleDrinkButton.TabIndex = 4;
            this.AppleDrinkButton.Text = "Apple Drink";
            this.AppleDrinkButton.UseVisualStyleBackColor = false;
            // 
            // liquidMangoButton
            // 
            this.liquidMangoButton.BackColor = System.Drawing.Color.LightCoral;
            this.liquidMangoButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.liquidMangoButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.liquidMangoButton.Location = new System.Drawing.Point(633, 233);
            this.liquidMangoButton.Name = "liquidMangoButton";
            this.liquidMangoButton.Size = new System.Drawing.Size(116, 66);
            this.liquidMangoButton.TabIndex = 5;
            this.liquidMangoButton.Text = "Liquid-Mango Drink";
            this.liquidMangoButton.UseVisualStyleBackColor = false;
            // 
            // RobertsonRedWine
            // 
            this.RobertsonRedWine.BackColor = System.Drawing.Color.DarkOrange;
            this.RobertsonRedWine.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RobertsonRedWine.Location = new System.Drawing.Point(567, 321);
            this.RobertsonRedWine.Name = "RobertsonRedWine";
            this.RobertsonRedWine.Size = new System.Drawing.Size(99, 66);
            this.RobertsonRedWine.TabIndex = 6;
            this.RobertsonRedWine.Text = "Robertson Red Wine";
            this.RobertsonRedWine.UseVisualStyleBackColor = false;
            // 
            // elementHost1
            // 
            this.elementHost1.Location = new System.Drawing.Point(30, 35);
            this.elementHost1.Name = "elementHost1";
            this.elementHost1.Size = new System.Drawing.Size(390, 375);
            this.elementHost1.TabIndex = 7;
            this.elementHost1.Text = "elementHost1";
            this.elementHost1.Child = null;
            // 
            // ReportingForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.elementHost1);
            this.Controls.Add(this.RobertsonRedWine);
            this.Controls.Add(this.liquidMangoButton);
            this.Controls.Add(this.AppleDrinkButton);
            this.Controls.Add(this.orbitChewingButton);
            this.Controls.Add(this.quantityInStockButton);
            this.Controls.Add(this.misterSweetApricot);
            this.Controls.Add(this.purchaseReportButton);
            this.Name = "ReportingForm";
            this.Text = "ReportingForm";
            this.Load += new System.EventHandler(this.ReportingForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button purchaseReportButton;
        private System.Windows.Forms.Button misterSweetApricot;
        private System.Windows.Forms.Button quantityInStockButton;
        private System.Windows.Forms.Button orbitChewingButton;
        private System.Windows.Forms.Button AppleDrinkButton;
        private System.Windows.Forms.Button liquidMangoButton;
        private System.Windows.Forms.Button RobertsonRedWine;
        private System.Windows.Forms.Integration.ElementHost elementHost1;
    }
}