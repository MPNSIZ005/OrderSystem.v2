﻿
namespace OrderSystem.PresentationLayer
{
    partial class PickingListForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PickingListForm));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.clerkIDLabel = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.orderDateLabel = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.orderIDLabel = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.customerIDLabel = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.customerNameLabel = new System.Windows.Forms.Label();
            this.ordersComboBox = new System.Windows.Forms.ComboBox();
            this.OKbutton = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.orderItemsListView = new System.Windows.Forms.ListView();
            this.specialNoteTextBox = new System.Windows.Forms.ListView();
            this.backButton = new System.Windows.Forms.Button();
            this.doneButton = new System.Windows.Forms.Button();
            this.printButton = new System.Windows.Forms.Button();
            this.printPreviewButton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.customerAddressLabel = new System.Windows.Forms.Label();
            this.PoppelprintPreviewDialog = new System.Windows.Forms.PrintPreviewDialog();
            this.PoppelprintDocument = new System.Drawing.Printing.PrintDocument();
            this.PoppelprintDialog = new System.Windows.Forms.PrintDialog();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(46, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Select an Order";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(46, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Clerk ID";
            // 
            // clerkIDLabel
            // 
            this.clerkIDLabel.AutoSize = true;
            this.clerkIDLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clerkIDLabel.Location = new System.Drawing.Point(255, 93);
            this.clerkIDLabel.Name = "clerkIDLabel";
            this.clerkIDLabel.Size = new System.Drawing.Size(41, 13);
            this.clerkIDLabel.TabIndex = 2;
            this.clerkIDLabel.Text = "label3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(46, 124);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Order Date";
            // 
            // orderDateLabel
            // 
            this.orderDateLabel.AutoSize = true;
            this.orderDateLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.orderDateLabel.Location = new System.Drawing.Point(255, 124);
            this.orderDateLabel.Name = "orderDateLabel";
            this.orderDateLabel.Size = new System.Drawing.Size(41, 13);
            this.orderDateLabel.TabIndex = 4;
            this.orderDateLabel.Text = "label5";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(46, 162);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Order ID";
            // 
            // orderIDLabel
            // 
            this.orderIDLabel.AutoSize = true;
            this.orderIDLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.orderIDLabel.Location = new System.Drawing.Point(255, 162);
            this.orderIDLabel.Name = "orderIDLabel";
            this.orderIDLabel.Size = new System.Drawing.Size(41, 13);
            this.orderIDLabel.TabIndex = 6;
            this.orderIDLabel.Text = "label7";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(46, 197);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(76, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Customer ID";
            // 
            // customerIDLabel
            // 
            this.customerIDLabel.AutoSize = true;
            this.customerIDLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customerIDLabel.Location = new System.Drawing.Point(255, 197);
            this.customerIDLabel.Name = "customerIDLabel";
            this.customerIDLabel.Size = new System.Drawing.Size(41, 13);
            this.customerIDLabel.TabIndex = 8;
            this.customerIDLabel.Text = "label9";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(46, 233);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(95, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Customer Name";
            // 
            // customerNameLabel
            // 
            this.customerNameLabel.AutoSize = true;
            this.customerNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customerNameLabel.Location = new System.Drawing.Point(258, 233);
            this.customerNameLabel.Name = "customerNameLabel";
            this.customerNameLabel.Size = new System.Drawing.Size(41, 13);
            this.customerNameLabel.TabIndex = 10;
            this.customerNameLabel.Text = "label1";
            // 
            // ordersComboBox
            // 
            this.ordersComboBox.FormattingEnabled = true;
            this.ordersComboBox.Location = new System.Drawing.Point(258, 16);
            this.ordersComboBox.Name = "ordersComboBox";
            this.ordersComboBox.Size = new System.Drawing.Size(210, 21);
            this.ordersComboBox.TabIndex = 11;
            // 
            // OKbutton
            // 
            this.OKbutton.Location = new System.Drawing.Point(498, 16);
            this.OKbutton.Name = "OKbutton";
            this.OKbutton.Size = new System.Drawing.Size(71, 22);
            this.OKbutton.TabIndex = 12;
            this.OKbutton.Text = "OK";
            this.OKbutton.UseVisualStyleBackColor = true;
            this.OKbutton.Click += new System.EventHandler(this.OKbutton_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.orderItemsListView);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(52, 322);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(473, 141);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Order Items";
            // 
            // orderItemsListView
            // 
            this.orderItemsListView.HideSelection = false;
            this.orderItemsListView.Location = new System.Drawing.Point(6, 19);
            this.orderItemsListView.Name = "orderItemsListView";
            this.orderItemsListView.Size = new System.Drawing.Size(461, 97);
            this.orderItemsListView.TabIndex = 0;
            this.orderItemsListView.UseCompatibleStateImageBehavior = false;
            // 
            // specialNoteTextBox
            // 
            this.specialNoteTextBox.HideSelection = false;
            this.specialNoteTextBox.Location = new System.Drawing.Point(52, 496);
            this.specialNoteTextBox.Name = "specialNoteTextBox";
            this.specialNoteTextBox.Size = new System.Drawing.Size(203, 97);
            this.specialNoteTextBox.TabIndex = 14;
            this.specialNoteTextBox.UseCompatibleStateImageBehavior = false;
            // 
            // backButton
            // 
            this.backButton.Location = new System.Drawing.Point(274, 496);
            this.backButton.Name = "backButton";
            this.backButton.Size = new System.Drawing.Size(75, 23);
            this.backButton.TabIndex = 15;
            this.backButton.Text = "Back";
            this.backButton.UseVisualStyleBackColor = true;
            this.backButton.Click += new System.EventHandler(this.backButton_Click);
            // 
            // doneButton
            // 
            this.doneButton.Location = new System.Drawing.Point(421, 496);
            this.doneButton.Name = "doneButton";
            this.doneButton.Size = new System.Drawing.Size(75, 23);
            this.doneButton.TabIndex = 16;
            this.doneButton.Text = "Done";
            this.doneButton.UseVisualStyleBackColor = true;
            this.doneButton.Click += new System.EventHandler(this.doneButton_Click);
            // 
            // printButton
            // 
            this.printButton.Location = new System.Drawing.Point(274, 558);
            this.printButton.Name = "printButton";
            this.printButton.Size = new System.Drawing.Size(75, 23);
            this.printButton.TabIndex = 17;
            this.printButton.Text = "Print";
            this.printButton.UseVisualStyleBackColor = true;
            this.printButton.Click += new System.EventHandler(this.printButton_Click);
            // 
            // printPreviewButton
            // 
            this.printPreviewButton.Location = new System.Drawing.Point(421, 558);
            this.printPreviewButton.Name = "printPreviewButton";
            this.printPreviewButton.Size = new System.Drawing.Size(75, 23);
            this.printPreviewButton.TabIndex = 18;
            this.printPreviewButton.Text = "Preview Button";
            this.printPreviewButton.UseVisualStyleBackColor = true;
            this.printPreviewButton.Click += new System.EventHandler(this.printPreviewButton_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(46, 262);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(108, 13);
            this.label3.TabIndex = 19;
            this.label3.Text = "Customer Address";
            // 
            // customerAddressLabel
            // 
            this.customerAddressLabel.AutoSize = true;
            this.customerAddressLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customerAddressLabel.Location = new System.Drawing.Point(258, 262);
            this.customerAddressLabel.Name = "customerAddressLabel";
            this.customerAddressLabel.Size = new System.Drawing.Size(41, 13);
            this.customerAddressLabel.TabIndex = 20;
            this.customerAddressLabel.Text = "label5";
            // 
            // PoppelprintPreviewDialog
            // 
            this.PoppelprintPreviewDialog.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.PoppelprintPreviewDialog.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.PoppelprintPreviewDialog.ClientSize = new System.Drawing.Size(400, 300);
            this.PoppelprintPreviewDialog.Enabled = true;
            this.PoppelprintPreviewDialog.Icon = ((System.Drawing.Icon)(resources.GetObject("PoppelprintPreviewDialog.Icon")));
            this.PoppelprintPreviewDialog.Name = "PoppelprintPreviewDialog";
            this.PoppelprintPreviewDialog.Visible = false;
            // 
            // PoppelprintDialog
            // 
            this.PoppelprintDialog.UseEXDialog = true;
            // 
            // PickingListForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(613, 618);
            this.Controls.Add(this.customerAddressLabel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.printPreviewButton);
            this.Controls.Add(this.printButton);
            this.Controls.Add(this.doneButton);
            this.Controls.Add(this.backButton);
            this.Controls.Add(this.specialNoteTextBox);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.OKbutton);
            this.Controls.Add(this.ordersComboBox);
            this.Controls.Add(this.customerNameLabel);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.customerIDLabel);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.orderIDLabel);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.orderDateLabel);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.clerkIDLabel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "PickingListForm";
            this.Text = "PickingListForm";
            this.Load += new System.EventHandler(this.PickingListForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label clerkIDLabel;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label orderDateLabel;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label orderIDLabel;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label customerIDLabel;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label customerNameLabel;
        private System.Windows.Forms.ComboBox ordersComboBox;
        private System.Windows.Forms.Button OKbutton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListView orderItemsListView;
        private System.Windows.Forms.ListView specialNoteTextBox;
        private System.Windows.Forms.Button backButton;
        private System.Windows.Forms.Button doneButton;
        private System.Windows.Forms.Button printButton;
        private System.Windows.Forms.Button printPreviewButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label customerAddressLabel;
        private System.Windows.Forms.PrintPreviewDialog PoppelprintPreviewDialog;
        private System.Drawing.Printing.PrintDocument PoppelprintDocument;
        private System.Windows.Forms.PrintDialog PoppelprintDialog;
    }
}