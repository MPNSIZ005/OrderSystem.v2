﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OrderSystem.BusinessLayer;

namespace OrderSystem.PresentationLayer
{
    public partial class PoppelMDIParent : Form
    {

        private int childFormNumber = 0;

        #region
        private ExpiredProductsForm expiredProductsForm;
        private RegistrationForm registrationForm;
        private PickingListForm pickingListForm;
        private CreateOrderForm createOrderForm;
        private CatalogueForm catalogueForm;
        private LoginForm loginForm;
        private ReportingForm reportingForm;
        private OrderItemsController orderItemsController;
        private EmployeeController employeeController;
        private CustomerController customerController;
        private ProductController productController;
        private OrderController orderController;

        #endregion
        public PoppelMDIParent()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
            orderItemsController = new OrderItemsController();
            employeeController = new EmployeeController();
            customerController = new CustomerController();
            productController = new ProductController();
            orderController = new OrderController();

            HideAll();
        }
        private void ShowNewForm(object sender, EventArgs e)
        {
            Form childForm = new Form();
            childForm.MdiParent = this;
            childForm.Text = "Window " + childFormNumber++;
            childForm.Show();
        }

        private void OpenFile(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            openFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (openFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = openFileDialog.FileName;
            }
        }

        #region Button Click Events
        private void SaveAs_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            saveFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (saveFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = saveFileDialog.FileName;
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            foreach (Form childForm in MdiChildren)
            {
                childForm.Close();
            }
        }

        private void login_Click(object sender, EventArgs e)
        {
            if (loginForm == null)
            {
                CreateLoginForm();
            }
            if (loginForm.loginFormClosed)
            {
                CreateLoginForm();
            }
            loginForm.Show();
           
        }

        private void logout_Click(object sender, EventArgs e)
        {
            HideAll();
        }

        private void catalogue_Click(object sender, EventArgs e)
        {
            if (catalogueForm == null)
            {
                CreateNewCatalogueForm();
            }
            if (catalogueForm.catalogueClosed)
            {
                CreateNewCatalogueForm();
            }
            catalogueForm.Show();
        }

        private void RegisterCustomer_Click(object sender, EventArgs e)
        {
            if(registrationForm == null)
            {
                CreateNewRegistrationForm();
            }
            if (registrationForm.registrationFormClosed)
            {
                CreateNewRegistrationForm();
            }
            registrationForm.Show();
        }

        private void pickingList_Click(object sender, EventArgs e)
        {
            if (pickingListForm == null)
            {
                CreateNewPickingListForm();
            }

            if (pickingListForm.listFormClosed)
            {
                CreateNewPickingListForm();
            }
            pickingListForm.Show();
        }

        private void createOrder_Click(object sender, EventArgs e)
        {
            if (createOrderForm == null)
            {
                CreateNewOrderForm();
            }

            if (createOrderForm.createOrderFormClosed)
            {
                CreateNewOrderForm();
            }

            createOrderForm.Show();
        }

        private void expiredProducts_Click(object sender, EventArgs e)
        {
            if (expiredProductsForm == null)
            {
                CreateNewExpiredProductsForm();
            }

            if (expiredProductsForm.productsFormClosed)
            {
                CreateNewExpiredProductsForm();
            }

            expiredProductsForm.Show();
        }

        private void salesReport_Click(object sender, EventArgs e)
        {
            if (reportingForm == null)
            {
                CreateNewReportingForm();
            }

            if (reportingForm.reportingFormClosed)
            {
                CreateNewReportingForm();
            }

            reportingForm.Show();
        }

        private void New_Click(object sender, EventArgs e)
        {
            Form childForm = new Form();
            childForm.MdiParent = this;
            childForm.Text = "Window" + childFormNumber++;
            childForm.Show();
        }

        private void Open_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            openFileDialog.Filter = "Text Files (*.txt) |*.txt|All Files (*.*)|*.*";
            if (openFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = openFileDialog.FileName;
            }
        }
        #endregion

        #region Methods
        private void CreateLoginForm()
        {
            loginForm = new LoginForm(employeeController);
            //loginForm.IsMdiContainer = true;
            loginForm.MdiParent = this;        // Setting the MDI Parent
            
            loginForm.StartPosition = FormStartPosition.CenterParent;
        }

        public void CreateNewCatalogueForm()
        {
            catalogueForm = new CatalogueForm(productController);
            //catalogueForm.MdiParent = this;        // Setting the MDI Parent
            catalogueForm.StartPosition = FormStartPosition.CenterParent;
        }
        private void CreateNewPickingListForm()
        {
            pickingListForm = new PickingListForm(productController, customerController, employeeController);
            pickingListForm.MdiParent = this;        // Setting the MDI Parent
            pickingListForm.StartPosition = FormStartPosition.CenterParent;
        }

        private void CreateNewRegistrationForm()
        {
            registrationForm = new RegistrationForm(customerController);
            registrationForm.MdiParent = this;        // Setting the MDI Parent
            registrationForm.StartPosition = FormStartPosition.CenterParent;
        }

        private void CreateNewExpiredProductsForm()
        {
            expiredProductsForm = new ExpiredProductsForm(productController);
            expiredProductsForm.MdiParent = this;        // Setting the MDI Parent
            expiredProductsForm.StartPosition = FormStartPosition.CenterParent;
        }

        private void CreateNewOrderForm()
        {
            createOrderForm = new CreateOrderForm(customerController);
            createOrderForm.MdiParent = this;        // Setting the MDI Parent
            createOrderForm.StartPosition = FormStartPosition.CenterParent;
        }
        private void CreateNewReportingForm()
        {
            reportingForm = new ReportingForm();
            reportingForm.MdiParent = this;        // Setting the MDI Parent
            reportingForm.StartPosition = FormStartPosition.CenterParent;
        }
        public void pickClerkLogin()
        {
            login.Visible = false;
            logout.Visible = true;
            printToolStripMenuItem1.Visible = true;
            createOrder.Visible = false;
            RegisterCustomer.Visible = false;
            salesReport.Visible = false;
        }

        public void TellerSellerLogin()
        {
            login.Visible = false;
            printToolStripMenuItem.Visible = true;
            createOrder.Visible = true;
            RegisterCustomer.Visible = true;
            salesReport.Visible = true;
        }

        public void HideAll()
        {
            RegisterCustomer.Visible = false;
            createOrder.Visible = false;
            printToolStripMenuItem.Visible = false;
            logout.Visible = false;
            login.Visible = true;
            salesReport.Visible = false;
        }
        #endregion
    }
}
